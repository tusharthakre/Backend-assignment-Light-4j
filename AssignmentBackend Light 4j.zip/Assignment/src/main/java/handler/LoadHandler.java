package handler;

import org.bson.Document;
import service.MongoDBService;
import utils.JSONPlaceholderClient;
import com.networknt.handler.LightHttpHandler;
import io.undertow.server.HttpServerExchange;

import java.util.List;

public class LoadHandler implements LightHttpHandler {

    private final MongoDBService mongoDBService = new MongoDBService();
    private final JSONPlaceholderClient jsonPlaceholderClient = new JSONPlaceholderClient();

    @Override
    public void handleRequest(HttpServerExchange exchange) {
        try {
            List<String> users = jsonPlaceholderClient.fetchUsers();
            users.forEach(user -> mongoDBService.insert(Document.parse(user)));
            exchange.setStatusCode(200);
        } catch (Exception e) {
            exchange.setStatusCode(500);
            exchange.getResponseSender().send("Error loading data: " + e.getMessage());
        }
    }
}
