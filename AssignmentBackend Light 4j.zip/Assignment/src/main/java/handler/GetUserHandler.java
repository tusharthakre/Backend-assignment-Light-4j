package handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import io.undertow.server.HttpServerExchange;
import com.networknt.handler.LightHttpHandler;
import org.bson.Document;

import java.util.Optional;

public class GetUserHandler implements LightHttpHandler{

    private final MongoDatabase database;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public GetUserHandler(MongoDatabase database) {
        this.database = database;
    }

    @Override
    public void handleRequest(HttpServerExchange exchange) throws Exception {
        String userId = exchange.getQueryParameters().get("userId").getFirst(); // Extract userId from the URL
        MongoCollection<Document> collection = database.getCollection("users");

        Document user = collection.find(new Document("id", Integer.parseInt(userId))).first();
        if (user == null) {
            exchange.setStatusCode(404); // User not found
            exchange.getResponseSender().send("User not found");
        } else {
            exchange.setStatusCode(200);
            exchange.getResponseSender().send(user.toJson());
        }
    }

}
