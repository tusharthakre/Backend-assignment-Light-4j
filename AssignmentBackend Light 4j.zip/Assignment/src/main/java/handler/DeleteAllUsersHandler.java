package handler;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import io.undertow.server.HttpServerExchange;
import com.networknt.handler.LightHttpHandler;
import org.bson.Document;

public class DeleteAllUsersHandler implements LightHttpHandler{
    private final MongoDatabase database;

    public DeleteAllUsersHandler(MongoDatabase database) {
        this.database = database;
    }

    @Override
    public void handleRequest(HttpServerExchange exchange) {
        MongoCollection<Document> collection = database.getCollection("users");
        collection.deleteMany(new Document()); // Deletes all documents
        exchange.setStatusCode(200); // Success response
    }
}
