package handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import io.undertow.server.HttpServerExchange;
import com.networknt.handler.LightHttpHandler;
import org.bson.Document;

import java.util.Map;

public class UpdateUserHandler implements LightHttpHandler{
    private final MongoDatabase database;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public UpdateUserHandler(MongoDatabase database) {
        this.database = database;
    }

    @Override
    public void handleRequest(HttpServerExchange exchange) throws Exception {
        String userId = exchange.getQueryParameters().get("userId").getFirst(); // Extract userId from the URL
        MongoCollection<Document> collection = database.getCollection("users");
        Map<String, Object> userData = objectMapper.readValue(exchange.getInputStream(), Map.class);

        if (!userId.equals(userData.get("id").toString())) {
            exchange.setStatusCode(400); // Bad request: Mismatch in userId
            exchange.getResponseSender().send("User ID in URL and body do not match");
            return;
        }

        Document updatedUser = new Document(userData);
        Document result = collection.findOneAndReplace(new Document("id", Integer.parseInt(userId)), updatedUser);
        if (result == null) {
            exchange.setStatusCode(404); // User not found
            exchange.getResponseSender().send("User not found");
        } else {
            exchange.setStatusCode(200); // Updated successfully
            exchange.getResponseSender().send("User updated successfully");
        }
    }
}

