package handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import io.undertow.server.HttpServerExchange;
import com.networknt.handler.LightHttpHandler;
import org.bson.Document;

import java.util.Map;

public class PutUserHandler implements LightHttpHandler{
    private final MongoDatabase database;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public PutUserHandler(MongoDatabase database) {
        this.database = database;
    }

    @Override
    public void handleRequest(HttpServerExchange exchange) throws Exception {
        MongoCollection<Document> collection = database.getCollection("users");
        Map<String, Object> userData = objectMapper.readValue(exchange.getInputStream(), Map.class);

        Integer userId = (Integer) userData.get("id");
        if (collection.find(new Document("id", userId)).first() != null) {
            exchange.setStatusCode(409); // Conflict: User already exists
            exchange.getResponseSender().send("User already exists");
        } else {
            collection.insertOne(new Document(userData));
            exchange.setStatusCode(201); // Created
            exchange.getResponseSender().send("User added successfully");
        }
    }
}
