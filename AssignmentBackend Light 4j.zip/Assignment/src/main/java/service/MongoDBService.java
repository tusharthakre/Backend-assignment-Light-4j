package service;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class MongoDBService {

    private static final String CONNECTION_STRING = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "usersDB";
    private static final String COLLECTION_NAME = "users";
    private final MongoCollection<Document> collection;

    public MongoDBService() {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        collection = database.getCollection(COLLECTION_NAME);
    }

    public MongoCollection<Document> getCollection() {
        return collection;
    }

    public void insert(Document document) {
        collection.insertOne(document);
    }

    public void deleteAll() {
        collection.drop();
    }

    public Document findById(String id) {
        return collection.find(new Document("id", id)).first();
    }

    public void deleteById(String id) {
        collection.deleteOne(new Document("id", id));
    }

    public void update(String id, Document updatedDocument) {
        collection.replaceOne(new Document("id", id), updatedDocument);
    }

}
