package utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONPlaceholderClient {
    private static final String USERS_API = "https://jsonplaceholder.typicode.com/users";
    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<String> fetchUsers() throws Exception {
        URL url = new URL(USERS_API);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        return objectMapper.readValue(response.toString(), List.class);
    }
}
